function [P,Yaw] = UAVInput(t)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here


P=[0;0;0];
Yaw=1;
end